(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"library_atlas_1", frames: [[0,0,675,675],[677,447,138,454],[677,1325,193,133],[779,903,193,133],[779,1038,20,49],[677,0,196,445],[677,903,100,420],[0,677,675,675],[0,1354,675,675]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.btnmute = function() {
	this.initialize(ss["library_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.hadeslibraryblack = function() {
	this.initialize(ss["library_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.hadeslibrarybookbuttonA = function() {
	this.initialize(ss["library_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.hadeslibrarybookbuttonB = function() {
	this.initialize(ss["library_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.hadeslibraryflame = function() {
	this.initialize(ss["library_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.hadeslibraryghost = function() {
	this.initialize(ss["library_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.hadeslibrarysecretdoor = function() {
	this.initialize(ss["library_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.shorebackground = function() {
	this.initialize(ss["library_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.welcomebtnlisten = function() {
	this.initialize(ss["library_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.secretdoor = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.hadeslibrarysecretdoor();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secretdoor, new cjs.Rectangle(0,0,100,420), null);


(lib.ghost = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.hadeslibraryghost();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ghost, new cjs.Rectangle(0,0,196,445), null);


(lib.explore_words = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2
	this.instance = new lib.welcomebtnlisten();

	this.instance_1 = new lib.btnmute();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,675,675);


(lib.candleFlame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.hadeslibraryflame();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleY:0.8071,skewY:180,x:20,y:9},0).wait(1).to({skewY:0,x:0},0).wait(1).to({scaleY:0.906,skewY:180,x:20,y:4},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,20,49);


(lib.book_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.hadeslibrarybookbuttonA();

	this.instance_1 = new lib.hadeslibrarybookbuttonB();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,193,133);


(lib.background_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_24 = function() {
		if(window.mysound == true){
			playSound('stone', 0);
		}
	}
	this.frame_269 = function() {
		if(window.mysound == true){
			playSound('stone', 0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(245).call(this.frame_269).wait(156));

	// background
	this.instance = new lib.shorebackground();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(425));

	// secret_door
	this.instance_1 = new lib.secretdoor();
	this.instance_1.setTransform(526,305,1,1,0,0,0,50,210);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24).to({x:420},52,cjs.Ease.quadInOut).wait(193).to({x:526},50,cjs.Ease.quadInOut).wait(106));

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AYx9hIVkAAMAAABG7I1kAAg");
	mask.setTransform(296.5,265);

	// ghost
	this.instance_2 = new lib.ghost();
	this.instance_2.setTransform(526,292.5,1,1,0,0,0,98,222.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(24).to({_off:false},0).to({x:561.95,y:314.5},58,cjs.Ease.quadInOut).to({y:275.5},59,cjs.Ease.quadInOut).to({x:500,y:317.5},60,cjs.Ease.quadInOut).to({x:539.95,y:307.5},58,cjs.Ease.quadInOut).to({x:526,y:292.5},60,cjs.Ease.quadInOut).to({_off:true},1).wait(105));

	// black
	this.instance_3 = new lib.hadeslibraryblack();
	this.instance_3.setTransform(455,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(425));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,675,675);


// stage content:
(lib.hadeslibrary = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		
		this.begin_btn.addEventListener("click", listenFunction.bind(this));
		window.mysound = false;
		
		function listenFunction() {
			if (window.mysound == false) {
				window.mysound = true;
				playSound('bg', -1);
				playSound('wail', -1);
				this.begin_btn.gotoAndStop(1);
			} else {
				window.mysound = false;
				createjs.Sound.stop();
				this.begin_btn.gotoAndStop(0);
			}
		
		}
		
		
		this.book.addEventListener("click", read.bind(this));
		function read() {
			
		window.open("https://riverstyx.glopilot.com/hades-library/#writings", "_parent");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// book
	this.book = new lib.book_btn();
	this.book.name = "book";
	this.book.setTransform(440,546.95,1,1,0,0,0,80,49);
	new cjs.ButtonHelper(this.book, 0, 1, 2, false, new lib.book_btn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.book).wait(1));

	// intro_cover
	this.begin_btn = new lib.explore_words();
	this.begin_btn.name = "begin_btn";
	this.begin_btn.setTransform(601,338.5,1,1,0,0,0,600,337.5);

	this.timeline.addTween(cjs.Tween.get(this.begin_btn).wait(1));

	// candles
	this.instance = new lib.candleFlame();
	this.instance.setTransform(124.05,335.05,0.4898,0.4898,0,0,0,10,24.5);

	this.instance_1 = new lib.candleFlame();
	this.instance_1.setTransform(619,113.55,0.4898,0.4898,0,0,0,10,24.5);

	this.instance_2 = new lib.candleFlame();
	this.instance_2.setTransform(427.55,126.05,0.4898,0.4898,0,0,0,10,24.5);

	this.instance_3 = new lib.candleFlame();
	this.instance_3.setTransform(223.55,121.05,0.4898,0.4898,0,0,0,10,24.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// background
	this.instance_4 = new lib.background_mc();
	this.instance_4.setTransform(601.55,340.65,1,1,0,0,0,600,337.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(338.5,338.5,338.1,339.70000000000005);
// library properties:
lib.properties = {
	id: '8F5835D99A6F4A4FA80B6087893675A7',
	width: 675,
	height: 675,
	fps: 31,
	color: "#000000",
	opacity: 0.01,
	manifest: [
		{src:"images/library_atlas_1.png?1669057730218", id:"library_atlas_1"},
		{src:"sounds/bg.mp3?1669057730284", id:"bg"},
		{src:"sounds/wail.mp3?1669057730284", id:"wail"},
		{src:"sounds/stone.mp3?1669057730284", id:"stone"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8F5835D99A6F4A4FA80B6087893675A7'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;