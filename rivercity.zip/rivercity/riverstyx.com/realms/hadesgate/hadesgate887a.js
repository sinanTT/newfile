(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"hadesgate_atlas_1", frames: [[0,0,675,675],[0,677,307,250],[811,677,110,115],[923,677,110,114],[685,677,124,109],[309,677,124,121],[435,677,124,114],[561,677,122,111],[677,0,675,675],[1354,0,675,675]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.btnmute = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.cerberusBody = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.head1A = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.head1B = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.head2A = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.head2B = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.head3A = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.head3B = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.shorebackground = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.welcomebtnlisten = function() {
	this.initialize(ss["hadesgate_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.gateGrowlBTN = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		/* stop();
		this.onRollOver = function() {
			_root.tooltipOn("Dare you proceed?");
			_root.growl2.setVolume(100);
			_root.growl2.start(0, 999999);
			
		
		};
		this.onRollOut = this.onDragOut=function () {
			_root.tooltipOff();
			_root.growl2.stop();
			
			
		
		};*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A5gZLQgTgVgOgWQgpg/gMhdQgGhrgEgxQgGhGgtjwQgnjRAAhuQAAhFBfhuQA3hBAKgNQAegoAAgZQAAgPgZg3QgohXgPgnQhQjJAAi/QAAh1BvjXQB7jrC+jTQDgj4EAiNQEuilE4AGIEOAAQFCBTENC/QBTA8CHBvQCTB7BCAxQCSBtCTDOIB4CuQBJBrAzBAQC1DkA1GaQAUCZAFDIQABBIAAD/QAADggGBFQgSC+hHBXQgVAbgdAcg");
	this.shape.setTransform(181.925,161.0411);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gateGrowlBTN, new cjs.Rectangle(0,0,363.9,322.1), null);


(lib.eye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgfAbQgRgdARgeQAjAjAkAYQgTAGgSAAQgRAAgRgGg");
	this.shape.setTransform(4.05,3.2625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.eye, new cjs.Rectangle(0,0,8.1,6.5), null);


(lib.explore_words = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2
	this.instance = new lib.welcomebtnlisten();

	this.instance_1 = new lib.btnmute();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,675,675);


(lib.body = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cerberusBody();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.body, new cjs.Rectangle(0,0,307,250), null);


(lib.background_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// background
	this.instance = new lib.shorebackground();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.background_mc, new cjs.Rectangle(0,0,675,675), null);


(lib.eyeHolder = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.eye();
	this.instance.setTransform(4.1,3.2,1,1,0,0,180,4,3.2);
	this.instance.shadow = new cjs.Shadow("rgba(255,0,0,1)",0,0,6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.eyeHolder, new cjs.Rectangle(-7,-7,26,24), null);


(lib.head3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_1 = function() {
		if (window.mysound == true) {
			playSound('bark', 0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(29));

	// head2B_png
	this.instance = new lib.eyeHolder();
	this.instance.setTransform(72.8,24.5,1,1,0,0,180,4,3.2);

	this.instance_1 = new lib.eyeHolder();
	this.instance_1.setTransform(117.7,24.5,1,1,0,0,0,4,3.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1,p:{y:24.5}},{t:this.instance,p:{y:24.5}}]}).to({state:[{t:this.instance_1,p:{y:33}},{t:this.instance,p:{y:33}}]},1).to({state:[{t:this.instance_1,p:{y:24.5}},{t:this.instance,p:{y:24.5}}]},4).wait(25));

	// head2A_png
	this.instance_2 = new lib.head2A();
	this.instance_2.setTransform(48.05,-4.9);

	this.instance_3 = new lib.head2B();
	this.instance_3.setTransform(48.05,2.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_2}]},4).wait(25));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(48.1,-4.9,124,128.2);


(lib.head2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_14 = function() {
		if (window.mysound == true) {
			playSound('bark', 0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(14).call(this.frame_14).wait(29));

	// head3B_png
	this.instance = new lib.eyeHolder();
	this.instance.setTransform(34.4,28.55,1,1,0,0,180,4,3.2);

	this.instance_1 = new lib.eyeHolder();
	this.instance_1.setTransform(79.3,28.55,1,1,0,0,0,4,3.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1,p:{y:28.55}},{t:this.instance,p:{y:28.55}}]}).to({state:[{t:this.instance_1,p:{y:43.05}},{t:this.instance,p:{y:43.05}}]},14).to({state:[{t:this.instance_1,p:{y:28.55}},{t:this.instance,p:{y:28.55}}]},4).wait(25));

	// head3A_png
	this.instance_2 = new lib.head3A();

	this.instance_3 = new lib.head3B();
	this.instance_3.setTransform(1.05,14.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},14).to({state:[{t:this.instance_2}]},4).wait(25));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,124,125.5);


(lib.head1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_34 = function() {
		if (window.mysound == true) {
			playSound('bark', 0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(34).call(this.frame_34).wait(29));

	// head1B_png
	this.instance = new lib.eyeHolder();
	this.instance.setTransform(34.6,34.8,1,1,0,0,180,4,3.2);

	this.instance_1 = new lib.eyeHolder();
	this.instance_1.setTransform(75.15,34.8,1,1,0,0,0,4,3.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1,p:{y:34.8}},{t:this.instance,p:{y:34.8}}]}).to({state:[{t:this.instance_1,p:{y:46.8}},{t:this.instance,p:{y:46.8}}]},34).to({state:[{t:this.instance_1,p:{y:34.8}},{t:this.instance,p:{y:34.8}}]},4).wait(25));

	// head1A_png
	this.instance_2 = new lib.head1A();

	this.instance_3 = new lib.head1B();
	this.instance_3.setTransform(-2,14);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},34).to({state:[{t:this.instance_2}]},4).wait(25));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2,0,112,128);


(lib.eyes3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.eyeHolder();
	this.instance.setTransform(4.1,3.2,1,1,0,0,180,4,3.2);

	this.instance_1 = new lib.eyeHolder();
	this.instance_1.setTransform(49,3.2,1,1,0,0,0,4,3.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.eyes3, new cjs.Rectangle(-7,-7,71,24), null);


(lib.eyes2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.eyeHolder();
	this.instance.setTransform(4.1,3.2,1,1,0,0,180,4,3.2);

	this.instance_1 = new lib.eyeHolder();
	this.instance_1.setTransform(49,3.2,1,1,0,0,0,4,3.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.eyes2, new cjs.Rectangle(-7,-7,71,24), null);


(lib.eyes1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.eyeHolder();
	this.instance.setTransform(4.1,3.2,1,1,0,0,180,4,3.2);

	this.instance_1 = new lib.eyeHolder();
	this.instance_1.setTransform(44.65,3.2,1,1,0,0,0,4,3.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.eyes1, new cjs.Rectangle(-7,-7,66.7,24), null);


(lib.eyesHolderMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_289 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(289).call(this.frame_289).wait(1));

	// head1A_png
	this.instance = new lib.head1();
	this.instance.setTransform(151,19.5,1,1,0,0,0,55,123.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.head1_mc = new lib.head1();
	this.head1_mc.name = "head1_mc";
	this.head1_mc.setTransform(151,19.5,1,1,0,0,0,55,123.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},180).to({state:[{t:this.head1_mc}]},30).wait(80));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(180).to({_off:false},0).to({_off:true,alpha:1},30,cjs.Ease.get(1)).wait(80));

	// head3B_png
	this.instance_1 = new lib.head2();
	this.instance_1.setTransform(281,57.5,1,1,0,0,0,99,112.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.head2_mc = new lib.head2();
	this.head2_mc.name = "head2_mc";
	this.head2_mc.setTransform(281,57.5,1,1,0,0,0,99,112.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},210).to({state:[{t:this.head2_mc}]},30).wait(50));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(210).to({_off:false},0).to({_off:true,alpha:1},30,cjs.Ease.get(1)).wait(50));

	// head2B_png
	this.instance_2 = new lib.head3();
	this.instance_2.setTransform(41,65,1,1,0,0,0,86,115);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.head3_mc = new lib.head3();
	this.head3_mc.name = "head3_mc";
	this.head3_mc.setTransform(41,65,1,1,0,0,0,86,115);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},240).to({state:[{t:this.head3_mc}]},30).wait(20));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(240).to({_off:false},0).to({_off:true,alpha:1},30,cjs.Ease.get(1)).wait(20));

	// cerberusBody_png
	this.instance_3 = new lib.body();
	this.instance_3.setTransform(148.5,21,1,1,0,0,0,153.5,125);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(262).to({_off:false},0).to({alpha:1},24,cjs.Ease.get(1)).wait(4));

	// Layer_22
	this.gateway_btn = new lib.gateGrowlBTN();
	this.gateway_btn.name = "gateway_btn";
	this.gateway_btn.setTransform(161.9,9.9,1,1,0,0,0,181.9,184.9);
	this.gateway_btn._off = true;

	this.timeline.addTween(cjs.Tween.get(this.gateway_btn).wait(51).to({_off:false},0).to({_off:true},1).wait(238));

	// head1A_png
	this.instance_4 = new lib.eyes1();
	this.instance_4.setTransform(150.9,115.8,1,1,0,0,0,24.4,3.2);
	this.instance_4._off = true;

	this.instance_5 = new lib.eyes2();
	this.instance_5.setTransform(150.9,115.8,1,1,0,0,0,26.6,3.2);

	this.instance_6 = new lib.eyes3();
	this.instance_6.setTransform(150.9,115.8,1,1,0,0,0,26.6,3.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},44).to({state:[]},3).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).to({state:[]},2).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]},1).to({state:[{t:this.instance_4}]},10).to({state:[{t:this.instance_4}]},93).to({state:[]},121).to({state:[]},14).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({_off:true},3).wait(1).to({_off:false},0).to({_off:true},2).wait(1).to({_off:false},0).wait(10).to({y:-69.7},93,cjs.Ease.get(1)).to({_off:true},121).wait(15));

	// head3B_png
	this.instance_7 = new lib.eyes2();
	this.instance_7.setTransform(150.9,115.8,1,1,0,0,0,26.6,3.2);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(61).to({_off:false},0).to({x:237.4,y:-26.45},93,cjs.Ease.get(1)).to({_off:true},121).wait(15));

	// head2B_png
	this.instance_8 = new lib.eyes3();
	this.instance_8.setTransform(150.9,115.8,1,1,0,0,0,26.6,3.2);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(61).to({_off:false},0).to({x:50.3,y:-25.5},93,cjs.Ease.get(1)).to({_off:true},121).wait(15));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20,-175,363.9,322.1);


// stage content:
(lib.hadesgate = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		
		this.begin_btn.addEventListener("click", listenFunction.bind(this));
		window.mysound = false;
		function listenFunction() {
			if (window.mysound == false) {
				window.mysound = true;
				playSound('bg', -1);
				playSound('growl1', -1);
				playSound('growl2', -1);
				this.begin_btn.gotoAndStop(1);
			} else {
				window.mysound = false;
				createjs.Sound.stop();
				this.begin_btn.gotoAndStop(0);
			}
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// intro_cover
	this.begin_btn = new lib.explore_words();
	this.begin_btn.name = "begin_btn";
	this.begin_btn.setTransform(601,338.5,1,1,0,0,0,600,337.5);

	this.timeline.addTween(cjs.Tween.get(this.begin_btn).wait(1));

	// Layer_1
	this.instance = new lib.eyesHolderMC();
	this.instance.setTransform(345.5,489.9,1,1,0,0,0,144.5,26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// background
	this.instance_1 = new lib.background_mc();
	this.instance_1.setTransform(601.55,340.65,1,1,0,0,0,600,337.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(338.5,338.5,338.1,339.70000000000005);
// library properties:
lib.properties = {
	id: '8F5835D99A6F4A4FA80B6087893675A7',
	width: 675,
	height: 675,
	fps: 31,
	color: "#000000",
	opacity: 0.01,
	manifest: [
		{src:"images/hadesgate_atlas_1.png?1669057745477", id:"hadesgate_atlas_1"},
		{src:"sounds/bark.mp3?1669057745519", id:"bark"},
		{src:"sounds/growl1.mp3?1669057745519", id:"growl1"},
		{src:"sounds/growl2.mp3?1669057745519", id:"growl2"},
		{src:"sounds/bg.mp3?1669057745519", id:"bg"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8F5835D99A6F4A4FA80B6087893675A7'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;