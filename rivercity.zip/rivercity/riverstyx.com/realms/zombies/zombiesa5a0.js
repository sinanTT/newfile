(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"zombies_atlas_1", frames: [[0,0,675,675],[1682,677,270,115],[1156,959,222,92],[677,0,675,675],[1354,0,675,675],[0,677,675,675],[1682,794,121,242],[1344,677,166,280],[1928,794,98,258],[1701,1038,69,74],[1954,677,74,83],[677,677,248,276],[1512,864,127,223],[1805,794,121,242],[1172,677,170,280],[1056,931,98,258],[1772,1038,69,74],[1428,1032,74,83],[927,931,127,223],[677,955,125,221],[1156,1053,70,46],[804,955,84,118],[1843,1038,69,56],[1641,1038,58,90],[927,677,243,252],[1512,677,168,185],[1380,959,103,71],[1641,864,33,38],[1380,1032,46,151]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.btnmute = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.car = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.carBase = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.hadesoraclezombiesbg2 = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.shorebackground = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.welcomebtnlisten = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.yg02a = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.yg02b = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.yg02c = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.yg02d = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.ym01b = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.yp01a = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.yp01c = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.zombie02a = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.zombie02b = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.zombie02c = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.zombie02d = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.zombie03b = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.zombie03c = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.zombieB02a = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.zombieB02b = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.zombieB02c = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.zombieB02d = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.zombieB02e = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.zombieB03a = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.zombieB03b = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.zombieB03d = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.zombieB03e = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.zombieCoffee = function() {
	this.initialize(ss["zombies_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.zombieCofee = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.zombieCoffee();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.zombieCofee, new cjs.Rectangle(0,0,46,151), null);


(lib.zombieRuinsArmPull_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.zombieB03d();
	this.instance.setTransform(5,24.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(5,24.5,103,71);


(lib.zombieRuin02ArmL_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.zombieB02e();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,58,90);


(lib.zombieBathArm_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.zombieB02b();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,70,46);


(lib.ym01TorsoB_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.zombie03c();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,127,223);


(lib.ym01TorsoA_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.yp01c();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,127,223);


(lib.ym01ArmA_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ym01b();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,74,83);


(lib.yg02TorsoB_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.zombie02b();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,280);


(lib.yg02TorsoA_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.yg02b();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,166,280);


(lib.yg02RightArmB_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.zombie02c();
	this.instance.setTransform(-27,14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,14,98,258);


(lib.yg02RightArmA_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.yg02c();
	this.instance.setTransform(-27,14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,14,98,258);


(lib.yg02LEgsB_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.zombie02a();
	this.instance.setTransform(0,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,1,121,242);


(lib.yg02LegsA_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.yg02a();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,121,242);


(lib.yg02HeadB_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.zombie02d();
	this.instance.setTransform(-19,3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19,3,69,74);


(lib.yg02HeadA_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.yg02d();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,74);


(lib.eyeBall_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","#FFFFFF","#90713F"],[0.224,0.4,1],0,0,0,0,0,3.3).s().p("AgRARQgHgGAAgLQAAgKAHgHQAHgHAKAAQALAAAGAHQAIAHAAAKQAAALgIAGQgGAIgLAAQgKAAgHgIg");
	this.shape.setTransform(2.5,2.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5,5);


(lib.coffeeSpill_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#330000").s().p("AgwAiQAAgEAJgHQAIgIAAgEQAAgHgNgPQgOgQAAgDQAAgOAKgEQAIgCAiAAQBBAAAAAxQAAAPghATQgdASgPAAQgeAAAAgRg");
	this.shape.setTransform(5.875,5.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,11.8,10.3);


(lib.coffee_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#330000").s().p("AhrA2QgrgXAAgfQAAgeArgXQAtgXA+AAQA/AAAsAXQAsAXAAAeQAAAfgsAXQgsAXg/gBQg+ABgtgXg");
	this.shape.setTransform(15.15,7.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30.3,15.3);


(lib.explore_words = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2
	this.instance = new lib.welcomebtnlisten();

	this.instance_1 = new lib.btnmute();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,675,675);


(lib.carMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.car();
	this.instance.setTransform(7,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.carMC, new cjs.Rectangle(7,0,270,115), null);


(lib.zombieRuinsMaleArmPull_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_2 = function() {
		playSound("rip");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(195));

	// Layer_1
	this.instance = new lib.zombieRuinsArmPull_gr("synched",0);
	this.instance.setTransform(56.5,85.5,1,1,0,0,0,56.5,85.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({regX:55.9,regY:86.4,scaleX:0.9999,scaleY:0.9999,rotation:-1.7858,y:86.4},0).wait(1).to({regX:56.5,regY:68,scaleX:1,scaleY:1,rotation:0,y:68},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-1.7858},0).wait(1).to({scaleX:1,scaleY:1,rotation:0},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-1.7858},0).wait(1).to({scaleX:1,scaleY:1,rotation:0},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-1.7858},0).wait(1).to({regX:55.9,regY:86.4,y:86.4},0).wait(1).to({regX:56.5,regY:68,scaleX:1,scaleY:1,rotation:0,y:68},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-1.7858},0).wait(1).to({scaleX:1,scaleY:1,rotation:0},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-1.7858},0).wait(1).to({scaleX:1,scaleY:1,rotation:0},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-1.7858},0).wait(1).to({startPosition:0},0).wait(1).to({regX:55.9,regY:86.4,y:86.4},0).wait(1).to({regX:56.5,regY:68,scaleX:1,scaleY:1,rotation:0,y:68},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-1.7858},0).wait(1).to({scaleX:1,scaleY:1,rotation:0},0).wait(1).to({regY:82.5,y:82.5},0).to({scaleX:0.9997,scaleY:0.9997,rotation:-19.7652,x:56,y:84.95},6).wait(91).to({startPosition:0},0).to({regY:85.5,scaleX:1,scaleY:1,rotation:0,x:56.5,y:85.5},10).wait(69));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12,13,121.5,101.6);


(lib.zombieCoffeeMoveMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_29 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_1
	this.instance = new lib.zombieCofee();
	this.instance.setTransform(23,240,1,0.6093,0,0,0,23,151);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1,y:151},29,cjs.Ease.get(1)).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,46,240);


(lib.zombieBathHead_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.eyeBall_gr("synched",0);
	this.instance.setTransform(36.7,37.3,1,1,0,0,0,2.5,2.5);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[36.7,37.4,43.3,39.3,44.5,33.7]}},19).to({guide:{path:[44.5,33.7,43.3,39.3,36.7,37.4]}},20).wait(1));

	// Layer_1
	this.instance_1 = new lib.zombieB02d();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(40));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,69,56);


(lib.ym01Torso_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ym01TorsoB_gr("synched",0);
	this.instance.setTransform(63.5,111.5,1,1,0,0,0,63.5,111.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.ym01TorsoA_gr("synched",0);
	this.instance_1.setTransform(63.5,111.5,1,1,0,0,0,63.5,111.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ym01Torso_mc, new cjs.Rectangle(0,0,127,223), null);


(lib.yg02Torso_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.yg02TorsoB_gr("synched",0);
	this.instance.setTransform(83,139,1,1,0,0,0,83,140);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.yg02TorsoA_gr("synched",0);
	this.instance_1.setTransform(83,140,1,1,0,0,0,83,140);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.yg02Torso_mc, new cjs.Rectangle(0,-1,170,281), null);


(lib.yg02RightArm_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.yg02RightArmB_gr("synched",0);
	this.instance.setTransform(49,129,1,1,0,0,0,22,143);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.yg02RightArmA_gr("synched",0);
	this.instance_1.setTransform(49,129,1,1,0,0,0,22,143);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.yg02RightArm_mc, new cjs.Rectangle(0,0,98,258), null);


(lib.yg02Legs_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.yg02LEgsB_gr("synched",0);
	this.instance.setTransform(60.5,121,1,1,0,0,0,60.5,121);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.yg02LegsA_gr("synched",0);
	this.instance_1.setTransform(60.5,121,1,1,0,0,0,60.5,121);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.yg02Legs_mc, new cjs.Rectangle(0,0,121,243), null);


(lib.yg02Head_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.yg02HeadB_gr("synched",0);
	this.instance.setTransform(36.55,39.4,1,1,0,0,0,34.5,37);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.yg02HeadA_gr("synched",0);
	this.instance_1.setTransform(17.35,42.45,1,1,0,0,0,34.5,37);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.yg02Head_mc, new cjs.Rectangle(-17.1,5.4,69.2,74.1), null);


(lib.coffee_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.coffee_gr("synched",0);
	this.instance.setTransform(15.2,7.7,1,1,0,0,0,15.2,7.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.coffee_mc, new cjs.Rectangle(0,0,30.3,15.3), null);


(lib.carMovingMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.carMC();
	this.instance.setTransform(135,57.5,1,1,0,0,0,135,57.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({y:60.5},0).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7,0,270,118);


(lib.zombieRuinsFemale02Torso_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.zombieBathHead_gr();
	this.instance.setTransform(35.65,38.2,1,1,0,0,0,33.2,45.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.9997,scaleY:0.9997,rotation:-5.7846},19).to({scaleX:1,scaleY:1,rotation:0},25).to({regY:45.3,scaleX:0.9994,scaleY:0.9994,rotation:10.518,y:38.25},25).to({regY:45.2,scaleX:1,scaleY:1,rotation:0,y:38.2},30).wait(1));

	// Layer_1
	this.instance_1 = new lib.zombieBathArm_gr("synched",0);
	this.instance_1.setTransform(4.3,52.6,1,1,-0.0009,0,0,62.3,9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:0.9991,scaleY:0.9991,rotation:-17.5723},49).to({scaleX:1,scaleY:1,rotation:-0.0009},50).wait(1));

	// Layer_3
	this.instance_2 = new lib.zombieB02c();
	this.instance_2.setTransform(-10.65,30);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(100));

	// Layer_4
	this.instance_3 = new lib.zombieRuin02ArmL_gr("synched",0);
	this.instance_3.setTransform(63,63,1,1,0,0,0,6,8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regY:8.1,scaleX:0.9989,scaleY:0.9989,rotation:-20.3322,x:63.05,y:63.05},34).to({regY:8,scaleX:1,scaleY:1,rotation:0,x:63,y:63},34).to({regX:6.1,scaleX:0.9989,scaleY:0.9989,rotation:-20.586,x:63.05,y:63.05},15,cjs.Ease.get(-1)).to({regX:6,scaleX:1,scaleY:1,rotation:0,x:63,y:63},16,cjs.Ease.get(1)).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.7,-12.3,199.10000000000002,160.3);


(lib.zombieBath02_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// legs
	this.instance = new lib.zombieB02a();
	this.instance.setTransform(-10.55,151);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(85));

	// upper
	this.zombie03b_mc = new lib.zombieRuinsFemale02Torso_mc();
	this.zombie03b_mc.name = "zombie03b_mc";
	this.zombie03b_mc.setTransform(69.1,152.5,1,1,0,0,0,32,121);

	this.timeline.addTween(cjs.Tween.get(this.zombie03b_mc).to({scaleX:0.9996,scaleY:0.9996,rotation:6.2703},39).to({scaleX:1,scaleY:1,rotation:0},45).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.9,22.1,179.70000000000002,349.9);


(lib.yg02Upper_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// head
	this.yg02HEad_mc = new lib.yg02Head_mc();
	this.yg02HEad_mc.name = "yg02HEad_mc";
	this.yg02HEad_mc.setTransform(35.85,12.15,0.9995,0.9995,-8.3027,0,0,23.1,49.6);

	this.timeline.addTween(cjs.Tween.get(this.yg02HEad_mc).to({scaleX:0.998,scaleY:0.998,rotation:26.3088,x:35.8},14).to({scaleX:0.9995,scaleY:0.9995,rotation:-8.3027,x:35.85},15).to({regX:22.9,scaleX:0.9979,scaleY:0.9979,rotation:39.8213,x:35.65,y:12.1},15).to({scaleX:0.9957,scaleY:0.9957,rotation:11.9764,y:12.2},15).to({regX:23.1,scaleX:0.9995,scaleY:0.9995,rotation:-8.3027,x:35.85,y:12.15},20).wait(1));

	// torsao
	this.yg02Torso_mc = new lib.yg02Torso_mc();
	this.yg02Torso_mc.name = "yg02Torso_mc";
	this.yg02Torso_mc.setTransform(81.2,142.4,1,1,0,0,0,83,140);

	this.timeline.addTween(cjs.Tween.get(this.yg02Torso_mc).wait(80));

	// r_arm
	this.yg02RightArm_mc = new lib.yg02RightArm_mc();
	this.yg02RightArm_mc.name = "yg02RightArm_mc";
	this.yg02RightArm_mc.setTransform(8.05,54.6,0.9995,0.9995,8.5141,0,0,64.8,15.6);

	this.timeline.addTween(cjs.Tween.get(this.yg02RightArm_mc).to({scaleX:0.9987,scaleY:0.9987,rotation:-6.7476,x:8,y:54.65},39).to({scaleX:0.9995,scaleY:0.9995,rotation:8.5141,x:8.05,y:54.6},40).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.8,-47.3,260,349.90000000000003);


(lib.yg02_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// legs
	this.yg02Legs_mc = new lib.yg02Legs_mc();
	this.yg02Legs_mc.name = "yg02Legs_mc";
	this.yg02Legs_mc.setTransform(60.5,121,1,1,0,0,0,60.5,121);

	this.timeline.addTween(cjs.Tween.get(this.yg02Legs_mc).wait(50));

	// upper_body
	this.yg02Upper_mc = new lib.yg02Upper_mc();
	this.yg02Upper_mc.name = "yg02Upper_mc";
	this.yg02Upper_mc.setTransform(74.4,14.3,0.999,0.999,-3.4634,0,0,65.1,124);

	this.timeline.addTween(cjs.Tween.get(this.yg02Upper_mc).to({scaleX:0.9983,scaleY:0.9983,rotation:8.1086,x:74.45},24).to({scaleX:0.999,scaleY:0.999,rotation:-3.4634,x:74.4},25).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-103.3,-145.2,296.8,388.2);


(lib.ym01ArmB_gr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.coffeeSpill_gr("synched",0);
	this.instance.setTransform(42.7,41.9,1,1,0,0,0,5.9,5.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(49));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ah/AcIgMhPIEXAAIgPAtQgIAphjAOQghADgbAAQhLAAgKgYg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:49.9875,y:37.8457}).wait(1).to({graphics:null,x:0,y:0}).wait(49));

	// Layer_3
	this.instance_1 = new lib.coffee_mc();
	this.instance_1.setTransform(53.4,44.25,0.9992,0.9992,14.0524,0,0,15.2,7.7);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(49));

	// Layer_1
	this.instance_2 = new lib.zombie03b();

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},1).wait(49));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,74,83);


(lib.cemetaryCoffeeSpill_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.coffeeSpill_gr("synched",0);
	this.instance.setTransform(62.15,39.75,0.9995,0.9995,171.2435,0,0,5.9,5.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({regY:5.1,scaleX:0.9965,scaleY:0.9965,rotation:280.0394,x:73.8,y:56.15,alpha:0},5).wait(29).to({scaleX:1,scaleY:1,rotation:360,x:42.7,y:41.9,alpha:1},0).to({regY:5.2,scaleX:0.997,scaleY:0.997,rotation:291.2917,x:32.2,y:57.15,alpha:0},4).wait(15));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah/AcIgMhPIEXAAIgPAtQgIAphjAOQghADgbAAQhLAAgKgYg");
	mask.setTransform(49.9875,37.8457);

	// Layer_3
	this.instance_1 = new lib.coffee_mc();
	this.instance_1.setTransform(52.7,44.35,0.9987,0.9987,-4.8038,0,0,15.2,7.7);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:7.6,rotation:-25.7938,x:51.85,y:44.5},13).to({regY:7.7,scaleX:0.9992,scaleY:0.9992,rotation:14.0524,x:53.4,y:44.25},34).to({scaleX:0.9987,scaleY:0.9987,rotation:-4.8038,x:52.7,y:44.35},18).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(25.8,32.7,52.8,30.299999999999997);


(lib.CarTopiaMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.carMovingMC();
	this.instance.setTransform(135,57.5,1,1,0,0,0,135,57.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// Layer_1
	this.instance_1 = new lib.carBase();
	this.instance_1.setTransform(15.85,58.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7,0,270,150.6);


(lib.zombieRuinsMaleBody_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_7
	this.instance = new lib.cemetaryCoffeeSpill_mc();
	this.instance.setTransform(121.6,47.4,0.9997,0.9997,5.2677);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.zombieB03b();
	this.instance_1.setTransform(35.9,14.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_4
	this.hairPull_mc = new lib.zombieRuinsMaleArmPull_mc();
	this.hairPull_mc.name = "hairPull_mc";
	this.hairPull_mc.setTransform(63.6,23.15,1,1,0,0,0,57.5,37);

	this.timeline.addTween(cjs.Tween.get(this.hairPull_mc).wait(1));

	// Layer_5
	this.instance_2 = new lib.zombieB03e();
	this.instance_2.setTransform(88.45,17.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.zombieRuinsMaleBody_mc, new cjs.Rectangle(11.1,10.7,192.8,188.9), null);


(lib.zombieRuinsMale01_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_6
	this.instance = new lib.zombieB03a();
	this.instance.setTransform(-31.2,170);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(66));

	// zombie03c_png
	this.instance_1 = new lib.zombieRuinsMaleBody_mc();
	this.instance_1.setTransform(90,181,1,1,0,0,0,77,181);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:0.9994,scaleY:0.9994,rotation:2.058,y:180.95},13,cjs.Ease.get(1)).to({scaleX:1,scaleY:1,rotation:0,y:181},18).to({regX:76.9,scaleX:0.9985,scaleY:0.9985,rotation:-5.3779,x:92.05,y:181.05},16,cjs.Ease.get(1)).to({regX:77,scaleX:1,scaleY:1,rotation:0,x:90,y:181},18,cjs.Ease.get(-1)).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.2,3.7,254,418.3);


(lib.zombieland = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// zombie02_mc
	this.zombie02_mc = new lib.zombieRuinsMale01_mc();
	this.zombie02_mc.name = "zombie02_mc";
	this.zombie02_mc.setTransform(333.35,350.65,1.0815,1.0815,0,0,0,90.2,212.3);

	this.timeline.addTween(cjs.Tween.get(this.zombie02_mc).wait(1));

	// zombie03_mc
	this.zombie03_mc = new lib.zombieBath02_mc();
	this.zombie03_mc.name = "zombie03_mc";
	this.zombie03_mc.setTransform(199.05,379.2,1.041,1.041,0,0,0,62.1,191.1);

	this.timeline.addTween(cjs.Tween.get(this.zombie03_mc).wait(1));

	// hades_oracle_zombies_bg2_png
	this.instance = new lib.hadesoraclezombiesbg2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.zombieland, new cjs.Rectangle(0,0,675,675), null);


(lib.ym01Arm_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ym01ArmB_gr("synched",0);
	this.instance.setTransform(37,41.5,1,1,0,0,0,37,41.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.ym01ArmA_gr("synched",0);
	this.instance_1.setTransform(37,41.5,1,1,0,0,0,37,41.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ym01Arm_mc, new cjs.Rectangle(0,0,74,83), null);


(lib.ym01CoffeeHolder_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.coffeeSpill_gr("synched",0);
	this.instance.setTransform(42.7,41.9,1,1,0,0,0,5.9,5.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:5.2,scaleX:0.997,scaleY:0.997,rotation:-68.7083,x:32.2,y:57.15,alpha:0},4).wait(20).to({scaleX:0.9995,scaleY:0.9995,rotation:-188.7565,x:62.15,y:39.75,alpha:1},0).to({regY:5.1,scaleX:0.9965,scaleY:0.9965,rotation:-79.9606,x:73.8,y:56.15,alpha:0},5).wait(21));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah/AcIgMhPIEXAAIgPAtQgIAphjAOQghADgbAAQhLAAgKgYg");
	mask.setTransform(49.9875,37.8457);

	// Layer_3
	this.instance_1 = new lib.coffee_mc();
	this.instance_1.setTransform(53.4,44.25,0.9992,0.9992,14.0524,0,0,15.2,7.7);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:7.6,scaleX:0.9987,scaleY:0.9987,rotation:-25.7938,x:51.85,y:44.5},24).to({regY:7.7,scaleX:0.9992,scaleY:0.9992,rotation:14.0524,x:53.4,y:44.25},25).wait(1));

	// Layer_1
	this.ym01Arm_mc = new lib.ym01Arm_mc();
	this.ym01Arm_mc.name = "ym01Arm_mc";
	this.ym01Arm_mc.setTransform(37,41.5,1,1,0,0,0,37,41.5);

	this.timeline.addTween(cjs.Tween.get(this.ym01Arm_mc).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,78.6,83);


(lib.ym01CoffeeArm_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.ym01CoffeeHolder_mc = new lib.ym01CoffeeHolder_mc();
	this.ym01CoffeeHolder_mc.name = "ym01CoffeeHolder_mc";

	this.timeline.addTween(cjs.Tween.get(this.ym01CoffeeHolder_mc).to({scaleX:0.9989,scaleY:0.9989,rotation:22.3157,x:1.4,y:-7.1},24).to({scaleX:1,scaleY:1,rotation:0,x:0,y:0},25).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.1,-7.1,104.19999999999999,104.8);


(lib.ym01Body_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// torso
	this.ym01Torso_mc = new lib.ym01Torso_mc();
	this.ym01Torso_mc.name = "ym01Torso_mc";
	this.ym01Torso_mc.setTransform(84.5,104.5,1,1,0,0,0,63.5,111.5);

	this.timeline.addTween(cjs.Tween.get(this.ym01Torso_mc).wait(1));

	// arm
	this.ym01CoffeeArm_mc = new lib.ym01CoffeeArm_mc();
	this.ym01CoffeeArm_mc.name = "ym01CoffeeArm_mc";
	this.ym01CoffeeArm_mc.setTransform(124.95,83);

	this.timeline.addTween(cjs.Tween.get(this.ym01CoffeeArm_mc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ym01Body_mc, new cjs.Rectangle(21,-7,178,223), null);


(lib.ym01_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// zombie03c_png
	this.torso_mc = new lib.ym01Body_mc();
	this.torso_mc.name = "torso_mc";
	this.torso_mc.setTransform(95,174,0.9991,0.9991,0.9442,0,0,82,174);

	this.timeline.addTween(cjs.Tween.get(this.torso_mc).to({scaleX:0.9987,scaleY:0.9987,rotation:-7.1189,x:95.05},44,cjs.Ease.get(1)).to({scaleX:0.9991,scaleY:0.9991,rotation:0.9442,x:95},45).wait(1));

	// legs
	this.instance = new lib.yp01a();
	this.instance.setTransform(-22,156);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22,-13.5,248,445.5);


(lib.background_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_79 = new cjs.Graphics().p("EAmFAshIiYAqIAA6LIPPAAIAAaLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(79).to({graphics:mask_graphics_79,x:325.975,y:289.125}).wait(91));

	// Layer_7
	this.zombieCoffee_mc = new lib.zombieCoffeeMoveMC();
	this.zombieCoffee_mc.name = "zombieCoffee_mc";
	this.zombieCoffee_mc.setTransform(596,502.9,1,1,0,0,0,23,75.5);
	this.zombieCoffee_mc._off = true;

	var maskedShapeInstanceList = [this.zombieCoffee_mc];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.zombieCoffee_mc).wait(79).to({_off:false},0).wait(50).to({alpha:0},15).wait(26));

	// graveyard
	this.instance = new lib.zombieland();
	this.instance.setTransform(337.5,337.5,1,1,0,0,0,337.5,337.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(40).to({_off:false},0).to({alpha:1},39).wait(50).to({alpha:0},40).wait(1));

	// shoppers
	this.mallDude_mc = new lib.ym01_mc();
	this.mallDude_mc.name = "mallDude_mc";
	this.mallDude_mc.setTransform(337.5,337.35,1,1,0,0,0,104.3,200.2);

	this.mallChickLeft_mc = new lib.yg02_mc();
	this.mallChickLeft_mc.name = "mallChickLeft_mc";
	this.mallChickLeft_mc.setTransform(186.4,447.15,1,1,0,0,0,60.5,121);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mallChickLeft_mc},{t:this.mallDude_mc}]}).wait(170));

	// Layer_2
	this.autopia_mc = new lib.CarTopiaMC();
	this.autopia_mc.name = "autopia_mc";
	this.autopia_mc.setTransform(475,378.4,1,1,0,0,0,135,75.3);

	this.timeline.addTween(cjs.Tween.get(this.autopia_mc).wait(170));

	// mall
	this.instance_1 = new lib.shorebackground();

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(170));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,675,675);


// stage content:
(lib.zombies = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
		
		this.begin_btn.addEventListener("click", listenFunction.bind(this));
		var mysound = false;
		
		function listenFunction()
		{
			if (mysound == false) {
				mysound = true;
				playSound('bg', -1);
				this.begin_btn.gotoAndStop(1);
			} else {
				mysound = false;
				createjs.Sound.stop();
				this.begin_btn.gotoAndStop(0);
			}
		  
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// intro_cover
	this.begin_btn = new lib.explore_words();
	this.begin_btn.name = "begin_btn";
	this.begin_btn.setTransform(601,338.5,1,1,0,0,0,600,337.5);

	this.timeline.addTween(cjs.Tween.get(this.begin_btn).wait(1));

	// background
	this.instance = new lib.background_mc();
	this.instance.setTransform(601.55,340.65,1,1,0,0,0,600,337.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(338.5,338.5,338.1,339.70000000000005);
// library properties:
lib.properties = {
	id: '8F5835D99A6F4A4FA80B6087893675A7',
	width: 675,
	height: 675,
	fps: 31,
	color: "#000000",
	opacity: 0.01,
	manifest: [
		{src:"images/zombies_atlas_1.png?1669057628546", id:"zombies_atlas_1"},
		{src:"sounds/rip.mp3?1669057628631", id:"rip"},
		{src:"sounds/bg.mp3?1669057628631", id:"bg"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8F5835D99A6F4A4FA80B6087893675A7'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;